<footer class="footer">
  <div class="container-fluid">
    <div class="d-block mx-auto">
      <?php echo !is_null($footerTextInfo) ? replaceBaseUrl($footerTextInfo->copyright_text, 'summernote') : ''; ?>

    </div>
  </div>
</footer>
<?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/partials/footer.blade.php ENDPATH**/ ?>