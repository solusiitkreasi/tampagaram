<script>
  "use strict";

  var mainURL = "<?php echo e(url('/')); ?>";
  var imgupload = "<?php echo e(route('admin.summernote.upload')); ?>";
  var storeURL = "";
  var removeURL = "";
  var rmvdbURL = "";
  var loadImgs = "";
</script>


<script src="<?php echo e(asset('assets/js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/axios-0.21.0.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.ui.touch-punch.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery.timepicker.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery.scrollbar.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/bootstrap-notify.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/sweetalert.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/bootstrap-tagsinput.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/bootstrap-datepicker.min.js')); ?>"></script>

<!-- Datatable -->
<script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/dropzone.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery.dm-uploader.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/summernote-bs4.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jscolor.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/atlantis.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/fontawesome-iconpicker.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/webfont.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/misc.js')); ?>"></script>


<script type="text/javascript" src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>


<script type="text/javascript" src="<?php echo e(asset('assets/js/daterangepicker.min.js')); ?>"></script>


<script type="text/javascript" src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/admin-main.js')); ?>"></script>

<?php if(session()->has('success')): ?>
  <script>
    "use strict";
    var content = {};

    content.message = '<?php echo e(session('success')); ?>';
    content.title = 'Success';
    content.icon = 'fa fa-bell';

    $.notify(content, {
      type: 'success',
      placement: {
        from: 'top',
        align: 'right'
      },
      showProgressbar: true,
      time: 1000,
      delay: 4000
    });
  </script>
<?php endif; ?>

<?php if(session()->has('warning')): ?>
  <script>
    "use strict";
    var content = {};

    content.message = '<?php echo e(session('warning')); ?>';
    content.title = 'Warning!';
    content.icon = 'fa fa-bell';

    $.notify(content, {
      type: 'warning',
      placement: {
        from: 'top',
        align: 'right'
      },
      showProgressbar: true,
      time: 1000,
      delay: 4000
    });
  </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
  <script>
    "use strict";
    var content = {};

    content.message = '<?php echo e(session('error')); ?>';
    content.title = 'Error!';
    content.icon = 'fa fa-bell';

    $.notify(content, {
      type: 'danger',
      placement: {
        from: 'top',
        align: 'right'
      },
      showProgressbar: true,
      time: 1000,
      delay: 4000
    });
  </script>
<?php endif; ?>
<?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/partials/scripts.blade.php ENDPATH**/ ?>