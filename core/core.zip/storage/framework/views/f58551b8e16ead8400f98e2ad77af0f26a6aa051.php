<?php $__env->startSection('pageHeading'); ?>
  <?php if(!is_null($pageHeading)): ?>
    <?php echo e($pageHeading->services_title); ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php
    $metaKeys = !empty($details->meta_keyword_services) ? $details->meta_keyword_services : '';
    $metaDesc = !empty($details->meta_description_services) ? $details->meta_description_services : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <?php if(!is_null($pageHeading)): ?>
            <h1><?php echo e(convertUtf8($pageHeading->services_title)); ?></h1>
          <?php endif; ?>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <?php if(!is_null($pageHeading)): ?>
              <li><?php echo e(convertUtf8($pageHeading->services_title)); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Service Section Start -->
    <section class="service-section section-padding section-bg">
      <div class="container">
        <?php if(count($serviceInfos) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Service Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <!-- Section Title -->
          <div class="section-title text-center">
            <?php if(!is_null($secHeading)): ?>
              <span class="title-top"><?php echo e(convertUtf8($secHeading->service_section_title)); ?></span>
              <h1><?php echo e(convertUtf8($secHeading->service_section_subtitle)); ?></h1>
            <?php endif; ?>
          </div>

          <!-- Service Boxes -->
          <div class="row">
            <?php $__currentLoopData = $serviceInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4 col-md-6">
                <!-- Single Service -->
                <div
                  class="single-service-box service-white-bg text-center wow fadeIn animated"
                  data-wow-duration="1500ms"
                  data-wow-delay="<?php echo e($loop->iteration * 200); ?>ms"
                >
                  <span class="service-counter"><?php echo e($loop->iteration); ?></span>
                  <div class="service-icon">
                    <i class="<?php echo e($serviceInfo->service_icon); ?>"></i>
                  </div>
                  <h4><?php echo e(convertUtf8($serviceInfo->title)); ?></h4>
                  <p><?php echo e(strlen($serviceInfo->summary) > 35 ? substr($serviceInfo->summary, 0, 35) . '...' : $serviceInfo->summary); ?></p>
                  <?php if($serviceInfo->details_page_status == 1): ?>
                    <a href="<?php echo e(route('service_details', ['id' => $serviceInfo->service_id, 'slug' => $serviceInfo->slug])); ?>" class="read-more">
                      <?php echo e(__('read more')); ?> <i class="far fa-long-arrow-right"></i>
                    </a>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Service Section End -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/services/services.blade.php ENDPATH**/ ?>