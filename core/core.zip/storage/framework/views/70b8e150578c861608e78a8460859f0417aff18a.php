<div class="col-lg-4">
  <div class="sidebar-wrap">
    <div class="widget fillter-widget">
      <h4 class="widget-title"><?php echo e(__('Filters')); ?></h4>
      <form action="<?php echo e(route('rooms')); ?>" method="GET">
        <?php if($websiteInfo->room_category_status == 1): ?>
        <input type="hidden" name="category" value="<?php echo e(request()->input('category')); ?>">
        <?php endif; ?>
        <div class="input-wrap">
          <label for=""><strong><?php echo e(__('Check In / Out Date')); ?></strong></label>
          <input type="text" placeholder="<?php echo e(__('Dates')); ?>" id="date-range" name="dates" value="<?php echo e(request()->input('dates')); ?>" readonly>
        </div>

        <div class="input-wrap">
          <label for=""><strong><?php echo e(__('Beds')); ?></strong></label>
          <select class="nice-select" name="beds">
            <option selected value=""><?php echo e(__('All')); ?></option>

            <?php for($i = 1; $i <= $numOfBed; $i++): ?>
              <option value="<?php echo e($i); ?>" <?php echo e(request()->input('beds') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="input-wrap">
          <label for=""><strong><?php echo e(__('Baths')); ?></strong></label>
          <select class="nice-select" name="baths">
            <option selected value=""><?php echo e(__('All')); ?></option>

            <?php for($i = 1; $i <= $numOfBath; $i++): ?>
              <option value="<?php echo e($i); ?>" <?php echo e(request()->input('baths') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="input-wrap">
          <label for=""><strong><?php echo e(__('Guests')); ?></strong></label>
          <select class="nice-select" name="guests">
            <option selected value=""><?php echo e(__('All')); ?></option>

            <?php for($i = 1; $i <= $maxGuests; $i++): ?>
              <option value="<?php echo e($i); ?>" <?php echo e(request()->input('guests') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="input-wrap">
          <label for=""><strong><?php echo e(__('Sort By')); ?></strong></label>
          <select class="nice-select" name="sort_by">
            <option <?php echo e((!empty(request()->input('sort_by')) || request()->input('sort_by') == 'desc') ? 'selected' : ''); ?> value="desc"><?php echo e(__('Latest Rooms')); ?></option>
            <option <?php echo e((request()->input('sort_by') == 'asc') ? 'selected' : ''); ?> value="asc"><?php echo e(__('Oldest Rooms')); ?></option>
            <option <?php echo e((request()->input('sort_by') == 'price-asc') ? 'selected' : ''); ?> value="price-asc"><?php echo e(__('Rent: Low to High')); ?></option>
            <option <?php echo e((request()->input('sort_by') == 'price-desc') ? 'selected' : ''); ?> value="price-desc"><?php echo e(__('Rent: High to Low')); ?></option>
          </select>
        </div>

        <div class="input-wrap">
            <label for=""><strong><?php echo e(__('Rent')); ?> / <?php echo e(__('Night')); ?> (<?php echo e($websiteInfo->base_currency_text); ?>)</strong></label>
          <div class="price-range-wrap">
            <div class="slider-range">
              <div id="price-range-slider"></div>
            </div>

            <div class="price-ammount">
              <input type="text" id="amount" name="rents" readonly/>
            </div>
          </div>
        </div>

        <div class="input-wrap">
          <div class="checkboxes">
            <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($loop->iteration <= 3): ?>
                <p class="d-block">
                  <input type="checkbox" name="ammenities[]" value="<?php echo e($amenity->id); ?>" id="amm<?php echo e($amenity->id); ?>" <?php echo e(is_array(request()->input('ammenities')) && in_array($amenity->id, request()->input('ammenities')) ? 'checked' : ''); ?>>
                  <label for="amm<?php echo e($amenity->id); ?>"><?php echo e($amenity->name); ?></label>
                </p>
              <?php else: ?>
                <p class="d-none show-more">
                  <input type="checkbox" name="ammenities[]" value="<?php echo e($amenity->id); ?>" id="amm<?php echo e($amenity->id); ?>" <?php echo e(is_array(request()->input('ammenities')) && in_array($amenity->id, request()->input('ammenities')) ? 'checked' : ''); ?>>
                  <label for="amm<?php echo e($amenity->id); ?>"><?php echo e($amenity->name); ?></label>
                </p>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($amenities) > 3): ?>
              <div class="more-ammenities">
                <a href="#"><?php echo e(__('More Amenities')); ?>...</a>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <div class="input-wrap">
          <button type="submit" class="btn filled-btn btn-block">
            <?php echo e(__('Filter Rooms')); ?> <i class="far fa-long-arrow-right"></i>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->startSection('script'); ?>
  <script>
    "use strict";
    var currency_info = <?php echo json_encode($currencyInfo); ?>;
    var minprice = <?php echo e($minPrice); ?>;
    var maxprice = <?php echo e($maxPrice); ?>;
    var priceValues = [<?php echo e($minRent); ?>, <?php echo e($maxRent); ?>];
  </script>

  <script src="<?php echo e(asset('assets/js/room-sidebar.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/rooms/room_sidebar.blade.php ENDPATH**/ ?>