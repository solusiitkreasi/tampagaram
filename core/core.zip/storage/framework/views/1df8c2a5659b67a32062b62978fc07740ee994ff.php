<?php if($language->direction == 1): ?>
  <?php $__env->startSection('style'); ?>
    <style>
      form input, form textarea, select, form select {
        direction: rtl;
      }

      form .note-editor.note-frame .note-editing-area .note-editable {
        direction: rtl;
        text-align: right;
      }
    </style>
  <?php $__env->stopSection(); ?>
<?php endif; ?>
<?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/partials/rtl_style.blade.php ENDPATH**/ ?>