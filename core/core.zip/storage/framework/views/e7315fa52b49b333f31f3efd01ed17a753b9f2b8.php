<script>
  "use strict";

  var rtl = <?php echo e($currentLanguageInfo->direction); ?>;
  var baseURL = "<?php echo url('/'); ?>";
  var vapid_public_key = "<?php echo env('VAPID_PUBLIC_KEY'); ?>";
</script>


<script src="<?php echo e(asset('assets/js/modernizr-3.6.0.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery-3.4.1.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>

<?php if(session()->has('success')): ?>
  <script>
    "use strict";
    toastr['success']("<?php echo e(__(session('success'))); ?>");
  </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
  <script>
    "use strict";
    toastr['error']("<?php echo e(__(session('error'))); ?>");
  </script>
<?php endif; ?>


<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/push-notification.js')); ?>"></script>


<?php if($websiteInfo->is_whatsapp == 1): ?>
  <script type="text/javascript">
    var whatsapp_popup = <?php echo e($websiteInfo->whatsapp_popup); ?>;
    var whatsappImg = "<?php echo e(asset('assets/img/whatsapp.svg')); ?>";

    $(function () {
      $('#WAButton').floatingWhatsApp({
        phone: "<?php echo e($websiteInfo->whatsapp_number); ?>", //WhatsApp Business phone number
        headerTitle: "<?php echo e($websiteInfo->whatsapp_header_title); ?>", //Popup Title
        popupMessage: `<?php echo nl2br($websiteInfo->whatsapp_popup_message); ?>`, //Popup Message
        showPopup: whatsapp_popup == 1 ? true : false, //Enables popup display
        buttonImage: '<img src="' + whatsappImg + '" />', //Button Image
        position: "right" //Position: left | right
      });
    });
  </script>
<?php endif; ?>

<!--Start of Tawk.to Script-->
<?php if($websiteInfo->is_tawkto == 1): ?>
  <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();

    (function () {
      var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
      s1.async=true;
      s1.src='https://embed.tawk.to/<?php echo e($websiteInfo->tawkto_property_id); ?>/default';
      s1.charset='UTF-8';
      s1.setAttribute('crossorigin','*');
      s0.parentNode.insertBefore(s1,s0);
    })();
  </script>
<?php endif; ?>
<!--End of Tawk.to Script-->
<?php /**PATH C:\xampp\htdocs\solusiitkreasi\tampagaram\core\resources\views/frontend/partials/scripts.blade.php ENDPATH**/ ?>