<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('Service Details')); ?>

<?php $__env->stopSection(); ?>

<?php
    $metaKeys = !empty($details->meta_keywords) ? $details->meta_keywords : '';
    $metaDesc = !empty($details->meta_description) ? $details->meta_description : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(strlen($details->title) > 30 ? mb_substr($details->title, 0, 30) . '...' : $details->title); ?></h1>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <li><?php echo e(__('Service Details')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <section class="service-details-section pt-130 pb-130">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="service-sidebar">
              <div class="widgets service-cat">
                <h4 class="widget-title"><?php echo e(__('More Services')); ?></h4>
                <?php if(count($moreServices) == 0): ?>
                  <h5><?php echo e(__('No More Service Found!')); ?></h5>
                <?php else: ?>
                  <ul class="service-cat-list">
                    <?php $__currentLoopData = $moreServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moreService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(!is_null($moreService->service)): ?>
                        <li>
                            <?php
                                $href = "#";
                                if($moreService->service->details_page_status == 1) {
                                    $href = route('service_details', ['id' => $moreService->service_id, 'slug' => $moreService->slug]);
                                }
                            ?>
                          <a href="<?php echo e($href); ?>"><?php echo e($moreService->title); ?><i class="far fa-angle-right"></i></a>
                        </li>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <!-- Service Details Section Start -->
          <div class="col-lg-8">
            <div class="service-details">
              <h2 class="title"><?php echo e(convertUtf8($details->title)); ?></h2>
              <p><?php echo e($details->summary); ?></p>
              <p><?php echo replaceBaseUrl($details->content, 'summernote'); ?></p>
            </div>
          </div>
          <!-- Service Details Section End -->
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/services/service_details.blade.php ENDPATH**/ ?>