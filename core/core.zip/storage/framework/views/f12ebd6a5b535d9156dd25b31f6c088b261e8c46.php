<div class="col-lg-8">
  <?php if(count($roomInfos) == 0): ?>
    <div class="row text-center">
      <div class="col bg-white py-5">
        <h3><?php echo e(__('No Room Found!')); ?></h3>
      </div>
    </div>
  <?php else: ?>
    <div class="row">
      <?php $__currentLoopData = $roomInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
          <!-- Single Room -->
          <div class="single-room">
            <a class="room-thumb d-block" href="<?php echo e(route('room_details', [$roomInfo->room_id, $roomInfo->slug])); ?>">
              <img class="lazy" data-src="<?php echo e(asset('assets/img/rooms/' . $roomInfo->featured_img)); ?>" alt="room">
              <div class="room-price">
                <p><?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($roomInfo->rent); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?> / <?php echo e(__('Night')); ?></p>
              </div>
            </a>

            <div class="room-desc">
                <?php if($websiteInfo->room_category_status == 1): ?>
                <div class="room-cat">
                  <a class="d-block p-0" href="<?php echo e(route('rooms', ['category' => $roomInfo->id])); ?>"><?php echo e($roomInfo->name); ?></a>
                </div>
                <?php endif; ?>
              <h4>
                <a href="<?php echo e(route('room_details', ['id' => $roomInfo->room_id, 'slug' => $roomInfo->slug])); ?>"><?php echo e(strlen($roomInfo->title) > 45 ? mb_substr($roomInfo->title, 0, 45, 'utf-8') . '...' : $roomInfo->title); ?></a>
              </h4>
              <p><?php echo e($roomInfo->summary); ?></p>
              <ul class="room-info">
                <li><i class="far fa-bed"></i><?php echo e($roomInfo->bed); ?> <?php echo e($roomInfo->bed == 1 ? __('Bed') : __('Beds')); ?></li>
                <li><i class="far fa-bath"></i><?php echo e($roomInfo->bath); ?> <?php echo e($roomInfo->bath == 1 ? __('Bath') : __('Baths')); ?></li>
                <?php if(!empty($roomInfo->max_guests)): ?>
                <li><i class="far fa-users"></i><?php echo e($roomInfo->max_guests); ?> <?php echo e($roomInfo->max_guests == 1 ? __('Guest') : __('Guests')); ?></li>
                <?php endif; ?>
              </ul>
              <?php if($roomRating->room_rating_status == 1): ?>
                <?php
                    $avgRating = \App\Models\RoomManagement\RoomReview::where('room_id', $roomInfo->room_id)->avg('rating');
                ?>
                <div class="rate">
                    <div class="rating" style="width:<?php echo e($avgRating * 20); ?>%"></div>
                </div>
              <?php endif; ?>
            </div>

          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
  <div class="row">
      <div class="col-12">
          <?php echo e($roomInfos->appends(['category' => request()->input('category'), 'dates' => request()->input('dates'),'beds' => request()->input('beds'),'baths' => request()->input('baths'),'guests' => request()->input('guests'),'sort_by' => request()->input('sort_by'),'rents' => request()->input('rents'),'ammenities' => request()->input('ammenities')])->links()); ?>

      </div>
  </div>
</div>
<?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/rooms/grid_view.blade.php ENDPATH**/ ?>