<?php if ($__env->exists('backend.partials.rtl_style')) echo $__env->make('backend.partials.rtl_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Room Section')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Home Page')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Room Section')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-10">
              <div class="card-title"><?php echo e(__('Update Room Section')); ?></div>
            </div>

            <div class="col-lg-2">
              <?php if ($__env->exists('backend.partials.languages')) echo $__env->make('backend.partials.languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>

        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-6 offset-lg-3">
              <form
                id="ajaxForm"
                action="<?php echo e(route('admin.home_page.update_room_section', ['language' => request()->input('language')])); ?>"
                method="post"
              >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for=""><?php echo e(__('Room Section Title*')); ?></label>
                  <input
                    type="text"
                    class="form-control"
                    name="room_section_title"
                    value="<?php echo e($data != null ? $data->room_section_title : ''); ?>"
                  >
                  <p id="err_room_section_title" class="em text-danger mt-1 mb-0"></p>
                </div>

                <div class="form-group">
                  <label for=""><?php echo e(__('Room Section Subtitle*')); ?></label>
                  <input
                    type="text"
                    class="form-control"
                    name="room_section_subtitle"
                    value="<?php echo e($data != null ? $data->room_section_subtitle : ''); ?>"
                  >
                  <p id="err_room_section_subtitle" class="em text-danger mt-1 mb-0"></p>
                </div>

                <div class="form-group">
                  <label for=""><?php echo e(__('Room Section Text*')); ?></label>
                  <textarea
                    class="form-control"
                    name="room_section_text"
                    rows="5"
                    cols="80"
                  ><?php echo e($data != null ? $data->room_section_text : ''); ?></textarea>
                  <p id="err_room_section_text" class="em text-danger mt-1 mb-0"></p>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" id="submitBtn" class="btn btn-success">
                <?php echo e(__('Update')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/home_page/room_section.blade.php ENDPATH**/ ?>