<?php $__env->startSection('pageHeading'); ?>
  <?php if(!is_null($pageHeading)): ?>
    <?php echo e($pageHeading->gallery_title); ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php
    $metaKeys = !empty($seo->meta_keyword_gallery) ? $seo->meta_keyword_gallery : '';
    $metaDesc = !empty($seo->meta_description_gallery) ? $seo->meta_description_gallery : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <?php if(!is_null($pageHeading)): ?>
            <h1><?php echo e(convertUtf8($pageHeading->gallery_title)); ?></h1>
          <?php endif; ?>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <?php if(!is_null($pageHeading)): ?>
              <li><?php echo e(convertUtf8($pageHeading->gallery_title)); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Gallery Start -->
    <section class="gallery-wrap section-padding">
      <div class="container">
        <!-- if category is null then no gallery is available -->
        <?php if(count($categories) == 0 || count($galleryInfos) == 0): ?>
          <div class="row text-center">
            <div class="col">
              <h3><?php echo e(__('No Gallery Found!')); ?></h3>
            </div>
          </div>
        <?php else: ?>
          <div class="gallery-filter text-center">
            <ul class="list-inline">
              <li class="active" data-filter="*"><?php echo e(__('Show All')); ?></li>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $filterValue = '.' . strtolower($category->name);

                  if (str_contains($filterValue, ' ')) {
                    $filterValue = str_replace(' ', '-', $filterValue);
                  }
                ?>

                <li data-filter="<?php echo e($filterValue); ?>"><?php echo e(convertUtf8($category->name)); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>

          <div class="gallery-items">
            <div class="row gallery-filter-items">
              <?php $__currentLoopData = $galleryInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Single Item -->
                <?php
                  $galleryCategory = $galleryInfo->galleryCategory()->first();
                  $categoryName = strtolower($galleryCategory->name);

                  if (str_contains($categoryName, ' ')) {
                    $categoryName = str_replace(' ', '-', $categoryName);
                  }
                ?>

                <div class="col-lg-4 col-md-6 col-sm-6 <?php echo e($categoryName); ?>">
                  <a class="gallery-item lazy bg-light d-block" href="<?php echo e(asset('assets/img/gallery/' . $galleryInfo->gallery_img)); ?>" data-bg="<?php echo e(asset('assets/img/gallery/' . $galleryInfo->gallery_img)); ?>">
                    <div class="gallery-content">
                      <h3><?php echo e(convertUtf8($galleryInfo->title)); ?></h3>
                    </div>
                  </a>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <!-- Gallery End -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/gallery.blade.php ENDPATH**/ ?>