<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Settings')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Packages Management')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Settings')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-4">
              <div class="card-title d-inline-block"><?php echo e(__('Package Settings')); ?></div>
            </div>
          </div>
        </div>

        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-6 offset-lg-3">
              <form
                id="settingsForm"
                action="<?php echo e(route('admin.packages_management.update_settings')); ?>"
                method="POST"
              >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label><?php echo e(__('Category Status*')); ?></label>
                  <div class="selectgroup w-100">
                    <label class="selectgroup-item">
                      <input
                        type="radio"
                        name="package_category_status"
                        value="1"
                        class="selectgroup-input"
                        <?php echo e($data->package_category_status == 1 ? 'checked' : ''); ?>

                      >
                      <span class="selectgroup-button"><?php echo e(__('Active')); ?></span>
                    </label>

                    <label class="selectgroup-item">
                      <input
                        type="radio"
                        name="package_category_status"
                        value="0"
                        class="selectgroup-input"
                        <?php echo e($data->package_category_status == 0 ? 'checked' : ''); ?>

                      >
                      <span class="selectgroup-button"><?php echo e(__('Deactive')); ?></span>
                    </label>
                  </div>
                  <?php if($errors->has('package_category_status')): ?>
                    <p class="text-danger"><?php echo e($errors->first('package_category_status')); ?></p>
                  <?php endif; ?>

                  <p class="mt-2 text-warning">
                    <?php echo e(__('Specify whether the package category will be active or not.')); ?>

                  </p>
                </div>

                <div class="form-group">
                  <label><?php echo e(__('Rating Status*')); ?></label>
                  <div class="selectgroup w-100">
                    <label class="selectgroup-item">
                      <input
                        type="radio"
                        name="package_rating_status"
                        value="1"
                        class="selectgroup-input"
                        <?php echo e($data->package_rating_status == 1 ? 'checked' : ''); ?>

                      >
                      <span class="selectgroup-button"><?php echo e(__('Active')); ?></span>
                    </label>

                    <label class="selectgroup-item">
                      <input
                        type="radio"
                        name="package_rating_status"
                        value="0"
                        class="selectgroup-input"
                        <?php echo e($data->package_rating_status == 0 ? 'checked' : ''); ?>

                      >
                      <span class="selectgroup-button"><?php echo e(__('Deactive')); ?></span>
                    </label>
                  </div>
                  <?php if($errors->has('package_rating_status')): ?>
                    <p class="text-danger"><?php echo e($errors->first('package_rating_status')); ?></p>
                  <?php endif; ?>

                  <p class="mt-2 text-warning">
                    <?php echo e(__('Specify whether the rating system for package will be active or not.')); ?>

                  </p>
                </div>

                <div class="form-group">
                  <label><?php echo e(__('Guest Checkout Status*')); ?></label>
                  <div class="selectgroup w-100">
                    <label class="selectgroup-item">
                      <input
                        type="radio"
                        name="package_guest_checkout_status"
                        value="1"
                        class="selectgroup-input"
                        <?php echo e($data->package_guest_checkout_status == 1 ? 'checked' : ''); ?>

                      >
                      <span class="selectgroup-button"><?php echo e(__('Active')); ?></span>
                    </label>

                    <label class="selectgroup-item">
                      <input
                        type="radio"
                        name="package_guest_checkout_status"
                        value="0"
                        class="selectgroup-input"
                        <?php echo e($data->package_guest_checkout_status == 0 ? 'checked' : ''); ?>

                      >
                      <span class="selectgroup-button"><?php echo e(__('Deactive')); ?></span>
                    </label>
                  </div>
                  <?php if($errors->has('package_guest_checkout_status')): ?>
                    <p class="text-danger"><?php echo e($errors->first('package_guest_checkout_status')); ?></p>
                  <?php endif; ?>

                  <p class="mt-2 mb-0 text-warning">
                    <?php echo e(__('If guest checkout is active, then users can checkout without login.')); ?>

                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" form="settingsForm" class="btn btn-success">
                <?php echo e(__('Update')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/packages/settings.blade.php ENDPATH**/ ?>