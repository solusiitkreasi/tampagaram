<?php $__env->startSection('content'); ?>
<div class="page-header">
   <h4 class="page-title">Pages</h4>
   <ul class="breadcrumbs">
      <li class="nav-home">
         <a href="<?php echo e(route('admin.dashboard')); ?>">
         <i class="flaticon-home"></i>
         </a>
      </li>
      <li class="separator">
         <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
         <a href="#">Create Page</a>
      </li>
      <li class="separator">
         <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
         <a href="#">Pages</a>
      </li>
   </ul>
</div>
<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-header">
            <div class="card-title">Create Page</div>
         </div>
         <div class="card-body pt-5 pb-4">
            <div class="row">
               <div class="col-lg-10 offset-lg-1">
                <div class="alert alert-danger" id="pageErrors" style="display: none;">
                    <ul>

                    </ul>
                </div>

                <form id="pageForm" action="<?php echo e(route('admin.page.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6">
                             <div class="form-group">
                                 <label for="">Status **</label>
                                 <select class="form-control ltr" name="status">
                                     <option value="1">Active</option>
                                     <option value="0">Deactive</option>
                                 </select>
                             </div>
                        </div>
                       <div class="col-lg-6">
                           <div class="form-group">
                               <label for="">Serial Number **</label>
                               <input type="number" class="form-control ltr" name="serial_number" value="" placeholder="Enter Serial Number">
                               <p class="text-warning mb-0"><small>The higher the serial number is, the later the page will be shown.</small></p>
                            </div>
                       </div>
                    </div>



                    <div id="accordion" class="mt-5">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="version">
                               <div class="version-header" id="heading<?php echo e($language->id); ?>">
                                   <h5 class="mb-0">
                                       <button type="button" class="btn btn-link" data-toggle="collapse" data-target="#collapse<?php echo e($language->id); ?>" aria-expanded="<?php echo e($language->is_default == 1 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($language->id); ?>">
                                       <?php echo e($language->name); ?> Language <?php echo e($language->is_default == 1 ? "(Default)" : ""); ?>

                                       </button>
                                   </h5>
                               </div>


                               <div id="collapse<?php echo e($language->id); ?>" class="collapse <?php echo e($language->is_default == 1 ? 'show' : ''); ?>" aria-labelledby="heading<?php echo e($language->id); ?>" data-parent="#accordion">
                                   <div class="version-body">
                                       <div class="row">
                                           <div class="col-lg-12">
                                               <div class="form-group">
                                                   <label for="">Name **</label>
                                                   <input type="text" class="form-control <?php echo e($language->direction == 1 ? 'rtl' : ''); ?>" name="<?php echo e($language->code); ?>_name" value="" placeholder="Enter name">
                                               </div>
                                           </div>
                                       </div>

                                       <div class="row">
                                           <div class="col-lg-12">
                                               <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                                   <label for="" class="<?php echo e($language->direction == 1 ? 'text-left d-block ltr' : ''); ?>">Body **</label>
                                                   <textarea class="form-control summernote" name="<?php echo e($language->code); ?>_body" placeholder="Enter body" data-height="300"></textarea>
                                               </div>
                                           </div>
                                       </div>
                                       <div class="row">
                                           <div class="col-lg-12">
                                               <div class="form-group <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>">
                                                   <label class="<?php echo e($language->direction == 1 ? 'ltr text-left d-block' : ''); ?>">Meta Keywords</label>
                                                   <input class="form-control" name="<?php echo e($language->code); ?>_meta_keywords" value="" placeholder="Enter meta keywords" data-role="tagsinput">
                                               </div>
                                           </div>
                                       </div>
                                       <div class="row">
                                           <div class="col-lg-12">
                                               <div class="form-group">
                                                   <label>Meta Description</label>
                                                   <textarea class="form-control <?php echo e($language->direction == 1 ? 'rtl text-right' : ''); ?>" name="<?php echo e($language->code); ?>_meta_description" rows="5" placeholder="Enter meta description"></textarea>
                                               </div>
                                           </div>
                                       </div>

                                       <div class="row">
                                           <div class="col-12">
                                               <?php
                                                   $currLang = $language;
                                               ?>
                                                 <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <?php if($currLang->id == $language->id) continue; ?>

                                                     <div class="form-check py-0">
                                                         <label class="form-check-label">
                                                             <input class="form-check-input" type="checkbox" value="" onchange="cloneContent('collapse<?php echo e($currLang->id); ?>', 'collapse<?php echo e($language->id); ?>', event)">
                                                             <span class="form-check-sign">Clone for <strong class="text-capitalize text-secondary"><?php echo e($language->name); ?></strong> Language</span>
                                                         </label>
                                                     </div>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                           </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                 </form>
               </div>
            </div>
         </div>
         <div class="card-footer">
            <div class="form">
               <div class="form-group from-show-notify row">
                  <div class="col-12 text-center">
                     <button type="submit" form="pageForm" class="btn btn-success">Submit</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/admin-page.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/page/create.blade.php ENDPATH**/ ?>