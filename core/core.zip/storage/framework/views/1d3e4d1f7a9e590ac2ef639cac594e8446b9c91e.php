<?php if ($__env->exists('backend.partials.rtl_style')) echo $__env->make('backend.partials.rtl_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('FAQ Section')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Home Page')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('FAQ Section')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-10">
              <div class="card-title"><?php echo e(__('Update FAQ Section')); ?></div>
            </div>

            <div class="col-lg-2">
              <?php if ($__env->exists('backend.partials.languages')) echo $__env->make('backend.partials.languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>

        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-6 offset-lg-3">
              <form 
                id="faqSecForm" 
                action="<?php echo e(route('admin.home_page.update_faq_section', ['language' => request()->input('language')])); ?>" 
                method="POST"
              >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <div class="thumb-preview" id="thumbPreview1">
                    <?php if(!empty($data->faq_section_image)): ?>
                      <img src="<?php echo e(asset('assets/img/faq_section/' . $data->faq_section_image)); ?>" alt="image">
                    <?php else: ?>
                      <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="...">
                    <?php endif; ?>
                  </div>
                  <br><br>

                  <input type="hidden" id="fileInput1" name="faq_section_image">
                  <button 
                    id="chooseImage1" 
                    class="choose-image btn btn-primary" 
                    type="button" 
                    data-multiple="false" 
                    data-toggle="modal" 
                    data-target="#lfmModal1"
                  ><?php echo e(__('Choose Image')); ?></button>
                  <?php if($errors->has('faq_section_image')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('faq_section_image')); ?></p>
                  <?php endif; ?>

                  
                  <div 
                    class="modal fade lfm-modal" 
                    id="lfmModal1" 
                    tabindex="-1" 
                    role="dialog" 
                    aria-labelledby="lfmModalTitle" 
                    aria-hidden="true"
                  >
                    <i class="fas fa-times-circle"></i>

                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-body p-0">
                          <iframe 
                            src="<?php echo e(url('laravel-filemanager')); ?>?serial=1" 
                            style="width: 100%; height: 500px; overflow: hidden; border: none;"
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label for=""><?php echo e(__('FAQ Section Title*')); ?></label>
                  <input type="text" class="form-control" name="faq_section_title" value="<?php echo e($data != null ? $data->faq_section_title : ''); ?>">
                  <?php if($errors->has('faq_section_title')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('faq_section_title')); ?></p>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                  <label for=""><?php echo e(__('FAQ Section Subtitle*')); ?></label>
                  <input type="text" class="form-control" name="faq_section_subtitle" value="<?php echo e($data != null ? $data->faq_section_subtitle : ''); ?>">
                  <?php if($errors->has('faq_section_subtitle')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('faq_section_subtitle')); ?></p>
                  <?php endif; ?>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" form="faqSecForm" class="btn btn-success">
                <?php echo e(__('Update')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/home_page/faq_section.blade.php ENDPATH**/ ?>