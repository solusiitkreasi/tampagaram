<?php $__env->startSection('pageHeading'); ?>
  <?php echo e($details->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-keywords', "$details->meta_keywords"); ?>
<?php $__env->startSection('meta-description', "$details->meta_description"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section
      class="breadcrumb-area d-flex align-items-center position-relative bg-img-center"
      style="background-image: url(<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>);"
    >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(strlen($details->name) > 30 ? mb_substr($details->name, 0, 30) . '...' : $details->name); ?></h1>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>
            <li><?php echo e(strlen($details->name) > 30 ? mb_substr($details->name, 0, 30) . '...' : $details->name); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <section class="pt-100 pb-100">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
              <div class="custom-page-content">
                  <?php echo replaceBaseUrl($details->body, 'summernote'); ?>

              </div>
          </div>

        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/custom-page.blade.php ENDPATH**/ ?>