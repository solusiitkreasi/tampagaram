<?php if ($__env->exists('backend.partials.rtl_style')) echo $__env->make('backend.partials.rtl_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Brand Section')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Home Page')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Brand Section')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-4">
              <div class="card-title d-inline-block"><?php echo e(__('Brand Partners')); ?></div>
            </div>

            <div class="col-lg-3">
              <?php if ($__env->exists('backend.partials.languages')) echo $__env->make('backend.partials.languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-lg-4 offset-lg-1 mt-2 mt-lg-0">
              <a
                href="#"
                data-toggle="modal"
                data-target="#createModal"
                class="btn btn-primary btn-sm float-lg-right float-left"
              ><i class="fas fa-plus"></i> <?php echo e(__('Add Brand')); ?></a>
            </div>
          </div>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <?php if(count($brands) == 0): ?>
                <h3 class="text-center"><?php echo e(__('NO BRAND FOUND!')); ?></h3>
              <?php else: ?>
                <div class="row">
                  <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                      <div class="card">
                        <div class="card-body">
                          <img
                            src="<?php echo e(asset('assets/img/brands/' . $brand->brand_img)); ?>"
                            alt="brand image"
                            style="width:100%;"
                          >
                        </div>

                        <div class="card-footer text-center">
                          <a
                            class="editBtn btn btn-secondary btn-sm mr-2"
                            href="#"
                            data-toggle="modal"
                            data-target="#editModal"
                            data-id="<?php echo e($brand->id); ?>"
                            data-brand_img="<?php echo e(asset('assets/img/brands/' . $brand->brand_img)); ?>"
                            data-brand_url="<?php echo e($brand->brand_url); ?>"
                            data-serial_number="<?php echo e($brand->serial_number); ?>"
                          >
                            <span class="btn-label">
                              <i class="fas fa-edit"></i>
                            </span>
                            <?php echo e(__('Edit')); ?>

                          </a>

                          <form
                            class="deleteForm d-inline-block"
                            action="<?php echo e(route('admin.home_page.brand_section.delete_brand')); ?>"
                            method="post"
                          >
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="brand_id" value="<?php echo e($brand->id); ?>">
                            <button type="submit" class="btn btn-danger btn-sm deleteBtn">
                              <span class="btn-label">
                                <i class="fas fa-trash"></i>
                              </span>
                              <?php echo e(__('Delete')); ?>

                            </button>
                          </form>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <?php echo $__env->make('backend.home_page.brand_section.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <?php echo $__env->make('backend.home_page.brand_section.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/home_page/brand_section/index.blade.php ENDPATH**/ ?>