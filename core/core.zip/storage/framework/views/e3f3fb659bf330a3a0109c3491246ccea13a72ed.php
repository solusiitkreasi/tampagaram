<?php $__env->startSection('pageHeading'); ?>
  <?php if(!is_null($pageHeading)): ?>
    <?php echo e($pageHeading->contact_us_title); ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php
    $metaKeys = !empty($seo->meta_keyword_contact_us) ? $seo->meta_keyword_contact_us : '';
    $metaDesc = !empty($seo->meta_description_contact_us) ? $seo->meta_description_contact_us : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>


<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <?php if(!is_null($pageHeading)): ?>
            <h1><?php echo e(convertUtf8($pageHeading->contact_us_title)); ?></h1>
          <?php endif; ?>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <?php if(!is_null($pageHeading)): ?>
              <li><?php echo e(convertUtf8($pageHeading->contact_us_title)); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Contact Information Start -->
    <section class="contact-info-section">
      <div class="container">
        <div class="contact-info-boxes">
          <div class="row">
            <div class="col-lg-4 col-md-6">
              <div class="contact-info-box">
                <div class="contact-icon">
                  <i class="far fa-map-marker-alt"></i>
                </div>
                <h4><?php echo e(__('Address')); ?></h4>
                <p><?php echo e($websiteInfo->address); ?></p>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div class="contact-info-box">
                <div class="contact-icon">
                  <i class="far fa-envelope-open"></i>
                </div>
                <h4><?php echo e(__('Email')); ?></h4>
                <p><?php echo e($websiteInfo->support_email); ?></p>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 mx-auto">
              <div class="contact-info-box">
                <div class="contact-icon">
                  <i class="far fa-phone"></i>
                </div>
                <h4><?php echo e(__('Phone')); ?></h4>
                <p><?php echo e($websiteInfo->support_contact); ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Contact Information End -->

    <!-- Map Start -->
    <?php if(!empty($websiteInfo->latitude) && !empty($websiteInfo->longitude)): ?>
    <section class="contact-map">
        <iframe width="100%" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=<?php echo e($websiteInfo->latitude); ?>,%20<?php echo e($websiteInfo->longitude); ?>+(My%20Business%20Name)&amp;t=&amp;z=10&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
    </section>
    <?php endif; ?>
    <!-- Map End -->

    <!-- Send Mail Form Start -->
    <section class="contact-form">
      <div class="container">
        <div class="contact-form-wrap section-bg">
          <h2 class="form-title"><?php echo e(__('Send A Message')); ?></h2>
          <form action="<?php echo e(route('contact.send_mail')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-md-4 col-12">
                  <div class="mb-4">
                      <div class="input-wrap mb-0">
                        <input type="text" placeholder="<?php echo e(__('Full Name')); ?>" name="full_name">
                        <i class="far fa-user-alt"></i>
                      </div>
                      <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mb-0 ml-3 text-danger"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>

              <div class="col-md-4 col-12">
                <div class="mb-4">
                    <div class="input-wrap mb-0">
                      <input type="email" placeholder="<?php echo e(__('Email Address')); ?>" name="email">
                      <i class="far fa-envelope"></i>
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mb-0 ml-3 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="col-md-4 col-12">
                <div class="mb-4">
                    <div class="input-wrap mb-0">
                      <input type="text" placeholder="<?php echo e(__('Email Subject')); ?>" name="subject">
                      <i class="far fa-pencil"></i>
                    </div>
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mb-0 ml-3 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="col-12">
                <div class="mb-4">
                    <div class="input-wrap mb-0 text-area">
                      <textarea placeholder="<?php echo e(__('Write Message')); ?>" name="message"></textarea>
                      <i class="far fa-pencil"></i>
                    </div>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="mb-0 ml-3 text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <?php if($websiteInfo->google_recaptcha_status == 1): ?>
                <div class="col-12 text-center">
                    <div class="d-block mb-4">
                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php echo NoCaptcha::display(); ?>

                        <?php if($errors->has('g-recaptcha-response')): ?>
                        <?php
                            $errmsg = $errors->first('g-recaptcha-response');
                        ?>
                        <p class="text-danger mb-0 mt-2"><?php echo e(__("$errmsg")); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
              <?php endif; ?>

              <div class="col-12 text-center">
                <button type="submit" class="btn filled-btn">
                  <?php echo e(__('Send')); ?> <i class="far fa-long-arrow-right"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
    <!-- Send Mail Form End -->
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/contact.blade.php ENDPATH**/ ?>