<?php $__env->startSection('content'); ?>
  <div class="mt-2 mb-4">
    <h2 class="text-white pb-2"><?php echo e(__('Welcome back,')); ?> <?php echo e(Auth::guard('admin')->user()->first_name . ' ' . Auth::guard('admin')->user()->last_name . '!'); ?></h2>
  </div>

  
  <div class="row">
    <?php if(empty($admin->role) || (!empty($permissions) && in_array('Rooms Management', $permissions))): ?>
    <div class="col-sm-6 col-md-4">
      <a class="card card-stats card-primary card-round" href="<?php echo e(route('admin.rooms_management.rooms')); ?>">
        <div class="card-body">
          <div class="row">
            <div class="col-5">
              <div class="icon-big text-center">
                <i class="fas fa-hotel"></i>
              </div>
            </div>
            <div class="col-7 col-stats">
              <div class="numbers">
                <p class="card-category">Rooms</p>
                <h4 class="card-title"><?php echo e($roomsCount); ?></h4>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>
    <?php endif; ?>

    <?php if(empty($admin->role) || (!empty($permissions) && in_array('Room Bookings', $permissions))): ?>
    <div class="col-sm-6 col-md-4">
      <a class="card card-stats card-info card-round" href="<?php echo e(route('admin.room_bookings.all_bookings')); ?>">
        <div class="card-body">
          <div class="row">
            <div class="col-5">
              <div class="icon-big text-center">
                <i class="far fa-calendar-alt"></i>
              </div>
            </div>
            <div class="col-7 col-stats">
              <div class="numbers">
                <p class="card-category">All Room Bookings</p>
                <h4 class="card-title"><?php echo e($allRbCount); ?></h4>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-sm-6 col-md-4">
      <a class="card card-stats card-secondary card-round" href="<?php echo e(route('admin.room_bookings.paid_bookings')); ?>">
        <div class="card-body">
          <div class="row">
            <div class="col-5">
              <div class="icon-big text-center">
                <i class="far fa-calendar-check"></i>
              </div>
            </div>
            <div class="col-7 col-stats">
              <div class="numbers">
                <p class="card-category">Paid Room Bookings</p>
                <h4 class="card-title"><?php echo e($allPbCount); ?></h4>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>
    <?php endif; ?>

    <?php if(empty($admin->role) || (!empty($permissions) && in_array('Packages Management', $permissions))): ?>
    <div class="col-sm-6 col-md-4">
      <a class="card card-stats card-success card-round" href="<?php echo e(route('admin.packages_management.packages')); ?>">
        <div class="card-body">
          <div class="row">
            <div class="col-5">
              <div class="icon-big text-center">
                <i class="fas fa-plane-departure"></i>
              </div>
            </div>
            <div class="col-7 col-stats">
              <div class="numbers">
                <p class="card-category">Packages</p>
                <h4 class="card-title"><?php echo e($packagesCount); ?></h4>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>
    <?php endif; ?>

    <?php if(empty($admin->role) || (!empty($permissions) && in_array('Package Bookings', $permissions))): ?>
    <div class="col-sm-6 col-md-4">
      <a class="card card-stats card-warning card-round" href="<?php echo e(route('admin.package_bookings.all_bookings')); ?>">
        <div class="card-body">
          <div class="row">
            <div class="col-5">
              <div class="icon-big text-center">
                <i class="far fa-calendar-alt"></i>
              </div>
            </div>
            <div class="col-7 col-stats">
              <div class="numbers">
                <p class="card-category">All Package Bookings</p>
                <h4 class="card-title"><?php echo e($allPbCount); ?></h4>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-sm-6 col-md-4">
      <a class="card card-stats card-danger card-round" href="<?php echo e(route('admin.package_bookings.paid_bookings')); ?>">
        <div class="card-body">
          <div class="row">
            <div class="col-5">
              <div class="icon-big text-center">
                <i class="far fa-calendar-check"></i>
              </div>
            </div>
            <div class="col-7 col-stats">
              <div class="numbers">
                <p class="card-category">Paid Package Bookings</p>
                <h4 class="card-title"><?php echo e($paidPbCount); ?></h4>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>
    <?php endif; ?>
  </div>

  <div class="row">
    <div class="col-lg-6">
      <div class="row row-card-no-pd">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="card-head-row">
                <h4 class="card-title"><?php echo e(__('Recent Room Bookings')); ?></h4>
              </div>
              <p class="card-category">
                <?php echo e(__('Top 10 latest room bookings')); ?>

              </p>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-12">
                  <?php if(count($rbookings) == 0): ?>
                    <h3 class="text-center"><?php echo e(__('NO ROOM BOOKING FOUND!')); ?></h3>
                  <?php else: ?>
                    <div class="table-responsive">
                      <table class="table table-striped mt-3">
                        <thead>
                          <tr>
                            <th scope="col"><?php echo e(__('Room')); ?></th>
                            <th scope="col"><?php echo e(__('Rent')); ?></th>
                            <th scope="col"><?php echo e(__('Payment Status')); ?></th>
                            <th scope="col"><?php echo e(__('Actions')); ?></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $rbookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td>
                                <?php
                                    $title = $booking->hotelRoom->roomContent->where('language_id', $defaultLang->id)->first()->title;
                                ?>
                                <?php echo e(strlen($title) > 20 ? mb_substr($title, 0, 20, 'utf-8') . '...' : $title); ?>

                              </td>
                              <td><?php echo e($booking->currency_text_position == 'left' ? $booking->currency_text : ''); ?> <?php echo e($booking->grand_total); ?> <?php echo e($booking->currency_text_position == 'right' ? $booking->currency_text : ''); ?></td>
                              <td>
                                <?php if($booking->gateway_type == 'online'): ?>
                                  <?php if($booking->payment_status == 1): ?>
                                    <h2 class="d-inline-block"><span class="badge badge-success"><?php echo e(__('Paid')); ?></span></h2>
                                  <?php else: ?>
                                    <h2 class="d-inline-block"><span class="badge badge-danger"><?php echo e(__('Unpaid')); ?></span></h2>
                                  <?php endif; ?>
                                <?php else: ?>
                                  <form
                                    id="paymentStatusForm<?php echo e($booking->id); ?>" class="d-inline-block"
                                    action="<?php echo e(route('admin.room_bookings.update_payment_status')); ?>"
                                    method="post"
                                  >
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">

                                    <select
                                      class="form-control form-control-sm <?php echo e($booking->payment_status == 1 ? 'bg-success' : 'bg-danger'); ?>"
                                      name="payment_status"
                                      onchange="document.getElementById('paymentStatusForm<?php echo e($booking->id); ?>').submit();"
                                    >
                                      <option value="1" <?php echo e($booking->payment_status == 1 ? 'selected' : ''); ?>>
                                        <?php echo e(__('Paid')); ?>

                                      </option>
                                      <option value="0" <?php echo e($booking->payment_status == 0 ? 'selected' : ''); ?>>
                                        <?php echo e(__('Unpaid')); ?>

                                      </option>
                                    </select>
                                  </form>
                                <?php endif; ?>
                              </td>
                              <td>
                                <div class="dropdown">
                                  <button
                                    class="btn btn-secondary btn-sm dropdown-toggle"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                  >
                                    <?php echo e(__('Select')); ?>

                                  </button>

                                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a href="<?php echo e(route('admin.room_bookings.booking_details_and_edit', ['id' => $booking->id])); ?>" class="dropdown-item"><?php echo e(__('Details')); ?></a>

                                    <a href="<?php echo e(asset('assets/invoices/rooms/' . $booking->invoice)); ?>" class="dropdown-item" target="_blank"><?php echo e(__('Invoice')); ?></a>

                                    <a href="#" class="dropdown-item mailBtn" data-target="#mailModal" data-toggle="modal" data-customer_email="<?php echo e($booking->customer_email); ?>"><?php echo e(__('Send Mail')); ?></a>

                                    <form
                                      class="deleteForm d-block"
                                      action="<?php echo e(route('admin.room_bookings.delete_booking', ['id' => $booking->id])); ?>"
                                      method="post"
                                    >
                                      <?php echo csrf_field(); ?>
                                      <button type="submit" class="deleteBtn">
                                        <?php echo e(__('Delete')); ?>

                                      </button>
                                    </form>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="row row-card-no-pd">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="card-head-row">
                <h4 class="card-title"><?php echo e(__('Recent Package Bookings')); ?></h4>
              </div>
              <p class="card-category">
                <?php echo e(__('Top 10 latest package bookings')); ?>

              </p>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <?php if(count($pbookings) == 0): ?>
                    <h3 class="text-center"><?php echo e(__('NO PACKAGE BOOKING FOUND!')); ?></h3>
                  <?php else: ?>
                    <div class="table-responsive">
                      <table class="table table-striped mt-3">
                        <thead>
                          <tr>
                            <th scope="col"><?php echo e(__('Package')); ?></th>
                            <th scope="col"><?php echo e(__('Cost')); ?></th>
                            <th scope="col"><?php echo e(__('Payment Status')); ?></th>
                            <th scope="col"><?php echo e(__('Actions')); ?></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $pbookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td>
                                <?php
                                    $title = $booking->tourPackage->packageContent->where('language_id', $defaultLang->id)->first()->title;
                                ?>
                                <?php echo e(strlen($title) > 20 ? mb_substr($title, 0, 20, 'utf-8') . '...' : $title); ?>

                              </td>
                              <td><?php echo e($booking->currency_text_position == 'left' ? $booking->currency_text : ''); ?> <?php echo e($booking->grand_total); ?> <?php echo e($booking->currency_text_position == 'right' ? $booking->currency_text : ''); ?></td>
                              <td>
                                <?php if($booking->gateway_type == 'online'): ?>
                                  <?php if($booking->payment_status == 1): ?>
                                    <h2 class="d-inline-block"><span class="badge badge-success"><?php echo e(__('Paid')); ?></span></h2>
                                  <?php else: ?>
                                    <h2 class="d-inline-block"><span class="badge badge-danger"><?php echo e(__('Unpaid')); ?></span></h2>
                                  <?php endif; ?>
                                <?php else: ?>
                                  <form
                                    id="paymentStatusForm<?php echo e($booking->id); ?>" class="d-inline-block"
                                    action="<?php echo e(route('admin.package_bookings.update_payment_status')); ?>"
                                    method="post"
                                  >
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">

                                    <select
                                      class="form-control form-control-sm <?php echo e($booking->payment_status == 1 ? 'bg-success' : 'bg-danger'); ?>"
                                      name="payment_status"
                                      onchange="document.getElementById('paymentStatusForm<?php echo e($booking->id); ?>').submit();"
                                    >
                                      <option value="1" <?php echo e($booking->payment_status == 1 ? 'selected' : ''); ?>>
                                        <?php echo e(__('Paid')); ?>

                                      </option>
                                      <option value="0" <?php echo e($booking->payment_status == 0 ? 'selected' : ''); ?>>
                                        <?php echo e(__('Unpaid')); ?>

                                      </option>
                                    </select>
                                  </form>
                                <?php endif; ?>
                              </td>
                              <td>
                                <div class="dropdown">
                                  <button
                                    class="btn btn-secondary btn-sm dropdown-toggle"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                  >
                                    <?php echo e(__('Select')); ?>

                                  </button>

                                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a href="<?php echo e(route('admin.package_bookings.booking_details', ['id' => $booking->id])); ?>" class="dropdown-item"><?php echo e(__('Details')); ?></a>

                                    <a href="<?php echo e(asset('assets/invoices/packages/' . $booking->invoice)); ?>" class="dropdown-item" target="_blank"><?php echo e(__('Invoice')); ?></a>

                                    <a href="#" class="dropdown-item mailBtn" data-target="#mailModal" data-toggle="modal" data-customer_email="<?php echo e($booking->customer_email); ?>"><?php echo e(__('Send Mail')); ?></a>

                                    <form
                                      class="deleteForm d-block"
                                      action="<?php echo e(route('admin.package_bookings.delete_booking', ['id' => $booking->id])); ?>"
                                      method="post"
                                    >
                                      <?php echo csrf_field(); ?>
                                      <button type="submit" class="deleteBtn">
                                        <?php echo e(__('Delete')); ?>

                                      </button>
                                    </form>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  

  <?php if ($__env->exists('backend.rooms.send_mail')) echo $__env->make('backend.rooms.send_mail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/admin/dashboard.blade.php ENDPATH**/ ?>