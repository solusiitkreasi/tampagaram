<?php $__env->startSection('content'); ?>
<div class="page-header">
  <h4 class="page-title"><?php echo e(__('Information')); ?></h4>
  <ul class="breadcrumbs">
    <li class="nav-home">
      <a href="<?php echo e(route('admin.dashboard')); ?>">
        <i class="flaticon-home"></i>
      </a>
    </li>
    <li class="separator">
      <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
      <a href="#"><?php echo e(__('Basic Settings')); ?></a>
    </li>
    <li class="separator">
      <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
      <a href="#"><?php echo e(__('Information')); ?></a>
    </li>
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <form action="<?php echo e(route('admin.basic_settings.update_info')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card-header">
          <div class="row">
            <div class="col-lg-10">
              <div class="card-title"><?php echo e(__('Update Information')); ?></div>
            </div>
          </div>
        </div>

        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-6 offset-lg-3">
              <div class="form-group">
                <label><?php echo e(__('Website Title*')); ?></label>
                <input
                  type="text"
                  class="form-control"
                  name="website_title"
                  value="<?php echo e($data->website_title != null ? $data->website_title : ''); ?>"
                  placeholder="Enter Website Title"
                >
                <?php if($errors->has('website_title')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('website_title')); ?></p>
                <?php endif; ?>
              </div>

              <div class="form-group">
                <label><?php echo e(__('Support Email*')); ?></label>
                <input
                  type="email"
                  class="form-control ltr"
                  name="support_email"
                  value="<?php echo e($data->support_email != null ? $data->support_email : ''); ?>"
                  placeholder="Enter Support Email"
                >
                <?php if($errors->has('support_email')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('support_email')); ?></p>
                <?php endif; ?>
              </div>

              <div class="form-group">
                <label><?php echo e(__('Support Contact*')); ?></label>
                <input
                  type="text"
                  class="form-control"
                  name="support_contact"
                  value="<?php echo e($data->support_contact != null ? $data->support_contact : ''); ?>"
                  placeholder="Enter Support Contact"
                >
                <?php if($errors->has('support_contact')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('support_contact')); ?></p>
                <?php endif; ?>
              </div>

              <div class="form-group">
                <label><?php echo e(__('Address*')); ?></label>
                <input
                  type="text"
                  class="form-control"
                  name="address"
                  value="<?php echo e($data->address != null ? $data->address : ''); ?>"
                  placeholder="Enter Address"
                >
                <?php if($errors->has('address')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('address')); ?></p>
                <?php endif; ?>
              </div>

              <div class="form-group">
                <label><?php echo e(__('Latitude')); ?></label>
                <input
                  type="text"
                  class="form-control"
                  name="latitude"
                  value="<?php echo e($data->latitude != null ? $data->latitude : ''); ?>"
                  placeholder="Enter Latitude"
                >
                <?php if($errors->has('latitude')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('latitude')); ?></p>
                <?php endif; ?>
              </div>

              <div class="form-group">
                <label><?php echo e(__('Longitude')); ?></label>
                <input
                  type="text"
                  class="form-control"
                  name="longitude"
                  value="<?php echo e($data->longitude != null ? $data->longitude : ''); ?>"
                  placeholder="Enter Longitude"
                >
                <?php if($errors->has('longitude')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('longitude')); ?></p>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="form">
            <div class="row">
              <div class="col-12 text-center">
                <button type="submit" class="btn btn-success">
                  <?php echo e(__('Update')); ?>

                </button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/basic_settings/information.blade.php ENDPATH**/ ?>