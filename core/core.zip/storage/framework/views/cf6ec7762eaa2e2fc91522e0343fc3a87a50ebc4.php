<?php if ($__env->exists('backend.partials.rtl_style')) echo $__env->make('backend.partials.rtl_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Intro Section')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Home Page')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Intro Section')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-10">
              <div class="card-title"><?php echo e(__('Update Intro Section')); ?></div>
            </div>

            <div class="col-lg-2">
              <?php if ($__env->exists('backend.partials.languages')) echo $__env->make('backend.partials.languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>

        <div class="card-body pt-5 pb-4">
          <div class="row">
            <div class="col-lg-8 offset-lg-2">
              <form
                id="introSecForm"
                action="<?php echo e(route('admin.home_page.update_intro_section', ['language' => request()->input('language')])); ?>"
                method="POST"
              >
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <div class="thumb-preview" id="thumbPreview1">
                    <?php if(!empty($data->intro_img)): ?>
                      <img src="<?php echo e(asset('assets/img/intro_section/' . $data->intro_img)); ?>" alt="image">
                    <?php else: ?>
                      <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="...">
                    <?php endif; ?>
                  </div>
                  <br><br>

                  <input type="hidden" id="fileInput1" name="intro_img">
                  <button
                    id="chooseImage1"
                    class="choose-image btn btn-primary"
                    type="button"
                    data-multiple="false"
                    data-toggle="modal"
                    data-target="#lfmModal1"
                  ><?php echo e(__('Choose Image')); ?></button>
                  <?php if($errors->has('intro_img')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('intro_img')); ?></p>
                  <?php endif; ?>

                  
                  <div
                    class="modal fade lfm-modal"
                    id="lfmModal1"
                    tabindex="-1"
                    role="dialog"
                    aria-labelledby="lfmModalTitle"
                    aria-hidden="true"
                  >
                    <i class="fas fa-times-circle"></i>

                    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                      <div class="modal-content">
                        <div class="modal-body p-0">
                          <iframe
                            src="<?php echo e(url('laravel-filemanager')); ?>?serial=1"
                            style="width: 100%; height: 500px; overflow: hidden; border: none;"
                          ></iframe>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for=""><?php echo e(__('Intro Primary Title*')); ?></label>
                      <input type="text" class="form-control" name="intro_primary_title" value="<?php echo e($data != null ? $data->intro_primary_title : ''); ?>">
                      <?php if($errors->has('intro_primary_title')): ?>
                        <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('intro_primary_title')); ?></p>
                      <?php endif; ?>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for=""><?php echo e(__('Intro Secondary Title*')); ?></label>
                      <input type="text" class="form-control" name="intro_secondary_title" value="<?php echo e($data != null ? $data->intro_secondary_title : ''); ?>">
                      <?php if($errors->has('intro_secondary_title')): ?>
                        <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('intro_secondary_title')); ?></p>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label for=""><?php echo e(__('Intro Text*')); ?></label>
                  <textarea class="form-control" name="intro_text" rows="5" cols="80"><?php echo e($data != null ? $data->intro_text : ''); ?></textarea>
                  <?php if($errors->has('intro_text')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('intro_text')); ?></p>
                  <?php endif; ?>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" form="introSecForm" class="btn btn-success">
                <?php echo e(__('Update')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block"><?php echo e(__('Counter Informations')); ?></div>
          <a
            href="<?php echo e(route('admin.home_page.intro_section.create_count_info') . '?language=' . request()->input('language')); ?>"
            class="btn btn-sm btn-primary float-lg-right float-left"
          ><i class="fas fa-plus"></i> <?php echo e(__('Add')); ?></a>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <?php if(count($counterInfos) == 0): ?>
                <h3 class="text-center"><?php echo e(__('NO COUNTER INFO FOUND!')); ?></h3>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-striped mt-3">
                    <thead>
                      <tr>
                        <th scope="col"><?php echo e(__('#')); ?></th>
                        <th scope="col"><?php echo e(__('Icon')); ?></th>
                        <th scope="col"><?php echo e(__('Title')); ?></th>
                        <th scope="col"><?php echo e(__('Amount')); ?></th>
                        <th scope="col"><?php echo e(__('Serial Number')); ?></th>
                        <th scope="col"><?php echo e(__('Actions')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $counterInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counterInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><i class="<?php echo e($counterInfo->icon); ?>"></i></td>
                          <td><?php echo e(convertUtf8($counterInfo->title)); ?></td>
                          <td><?php echo e($counterInfo->amount); ?></td>
                          <td><?php echo e($counterInfo->serial_number); ?></td>
                          <td>
                            <a
                              class="btn btn-secondary btn-sm mr-1"
                              href="<?php echo e(route('admin.home_page.intro_section.edit_count_info', ['id' => $counterInfo->id]) . '?language=' . request()->input('language')); ?>"
                            >
                              <span class="btn-label">
                                <i class="fas fa-edit"></i>
                              </span>
                              <?php echo e(__('Edit')); ?>

                            </a>

                            <form
                              class="deleteForm d-inline-block"
                              action="<?php echo e(route('admin.home_page.intro_section.delete_count_info')); ?>" method="post"
                            >
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="counterInfo_id" value="<?php echo e($counterInfo->id); ?>">
                              <button type="submit" class="btn btn-danger btn-sm deleteBtn">
                                <span class="btn-label">
                                  <i class="fas fa-trash"></i>
                                </span>
                                <?php echo e(__('Delete')); ?>

                              </button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/home_page/intro_section/index.blade.php ENDPATH**/ ?>