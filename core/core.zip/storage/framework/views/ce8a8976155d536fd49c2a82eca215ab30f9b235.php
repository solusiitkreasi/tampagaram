<?php $__env->startSection('pageHeading'); ?>
  <?php echo e(__('404')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $breadcrumbInfo = App\Traits\MiscellaneousTrait::getBreadcrumb();
?>
<main>
    <!-- Breadcrumb Section Start -->
    <section
      class="breadcrumb-area d-flex align-items-center position-relative bg-img-center"
      style="background-image: url(<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>);"
    >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h1><?php echo e(__('Page Not Found')); ?></h1>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>
            <li><?php echo e(__('404')); ?></li>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!--    Error section start   -->
    <div class="error-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="not-found">
                        <img src="<?php echo e(asset('assets/img/404.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="error-txt">
                        <div class="oops">
                        <img src="<?php echo e(asset('assets/img/oops.png')); ?>" alt="">
                        </div>
                        <h2><?php echo e(__("You're lost")); ?>...</h2>
                        <p><?php echo e(__("The page you are looking for might have been moved, renamed, or might never existed.")); ?></p>
                        <a href="<?php echo e(route('index')); ?>" class="go-home-btn"><?php echo e(__("Back Home")); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--    Error section end   -->
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\solusiitkreasi\tampagaram\core\resources\views/errors/404.blade.php ENDPATH**/ ?>