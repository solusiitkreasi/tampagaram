<section class="hero-section slider-two" id="secondSlider">
    <?php if(count($sliders) != 0): ?>
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
          class="single-hero-slide bg-img-center d-flex align-items-center lazy"
          data-bg="<?php echo e(asset('assets/img/hero_slider/' . $slider->img)); ?>"
        >
          <div class="container">
            <div class="row">
              <div class="col-lg-7 col-md-10">
                <div class="slider-text">
                  <h1 data-animation="fadeInDown" data-delay=".3s">
                    
                    <?php echo e(convertUtf8($slider->title)); ?>

                  </h1>
                  <p data-animation="fadeInLeft" data-delay=".5s">
                    <?php echo e(convertUtf8($slider->subtitle)); ?>

                  </p>
                  <a class="btn filled-btn" href="<?php echo e($slider->btn_url); ?>" data-animation="fadeInUp" data-delay=".8s">
                    <?php echo e(convertUtf8($slider->btn_name)); ?> <i class="far fa-long-arrow-right"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="bg-light pt-70 pb-70 text-center">
            <h3><?php echo e(__('No Slider Found!')); ?></h4>
        </div>
    <?php endif; ?>
  </section>
<?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/partials/hero/theme2/slider.blade.php ENDPATH**/ ?>