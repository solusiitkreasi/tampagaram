<?php $__env->startSection('content'); ?>
<div class="page-header">
  <h4 class="page-title"><?php echo e(__('Logo')); ?></h4>
  <ul class="breadcrumbs">
    <li class="nav-home">
      <a href="<?php echo e(route('admin.dashboard')); ?>">
        <i class="flaticon-home"></i>
      </a>
    </li>
    <li class="separator">
      <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
      <a href="#"><?php echo e(__('Basic Settings')); ?></a>
    </li>
    <li class="separator">
      <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
      <a href="#"><?php echo e(__('Logo')); ?></a>
    </li>
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <div class="row">
          <div class="col-lg-10">
            <div class="card-title"><?php echo e(__('Update Logo')); ?></div>
          </div>
        </div>
      </div>

      <div class="card-body pt-5 pb-4">
        <div class="row">
          <div class="col-lg-6 offset-lg-3">
            <form id="imageForm" action="<?php echo e(route('admin.basic_settings.update_logo')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <div class="thumb-preview" id="thumbPreview1">
                  <?php if(!empty($data->logo)): ?>
                    <img src="<?php echo e(asset('assets/img/' . $data->logo)); ?>" alt="logo">
                  <?php else: ?>
                    <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="...">
                  <?php endif; ?>
                </div>
                <br><br>

                <input type="hidden" id="fileInput1" name="logo">
                <button 
                  id="chooseImage1" 
                  class="choose-image btn btn-primary" 
                  type="button" 
                  data-multiple="false" 
                  data-toggle="modal" 
                  data-target="#lfmModal1"
                ><?php echo e(__('Choose Image')); ?></button>
                <?php if($errors->has('logo')): ?>
                  <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('logo')); ?></p>
                <?php endif; ?>

                
                <div 
                  class="modal fade lfm-modal" 
                  id="lfmModal1" 
                  tabindex="-1" 
                  role="dialog" 
                  aria-labelledby="lfmModalTitle" 
                  aria-hidden="true"
                >
                  <i class="fas fa-times-circle"></i>

                  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                      <div class="modal-body p-0">
                        <iframe 
                          src="<?php echo e(url('laravel-filemanager')); ?>?serial=1" 
                          style="width: 100%; height: 500px; overflow: hidden; border: none;"
                        ></iframe>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <div class="card-footer">
        <div class="row">
          <div class="col-12 text-center">
            <button type="submit" form="imageForm" class="btn btn-success">
              <?php echo e(__('Update')); ?>

            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/basic_settings/logo.blade.php ENDPATH**/ ?>