<?php if ($__env->exists('backend.partials.rtl_style')) echo $__env->make('backend.partials.rtl_style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Testimonial Section')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Home Page')); ?></a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Testimonial Section')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-10">
              <div class="card-title"><?php echo e(__('Update Testimonial Section')); ?></div>
            </div>

            <div class="col-lg-2">
              <?php if ($__env->exists('backend.partials.languages')) echo $__env->make('backend.partials.languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>

        <div class="card-body pt-5 pb-5">
          <div class="row">
            <div class="col-lg-6 offset-lg-3">
              <form
                id="testimonialSecForm"
                action="<?php echo e(route('admin.home_page.update_testimonial_section', ['language' => request()->input('language')])); ?>"
                method="POST"
              >
                <?php echo csrf_field(); ?>
                <?php if($websiteInfo->theme_version == 'theme_two'): ?>
                  <div class="form-group">
                    <div class="thumb-preview" id="thumbPreview1">
                      <?php if(!empty($data->testimonial_section_image)): ?>
                        <img src="<?php echo e(asset('assets/img/testimonial_section/' . $data->testimonial_section_image)); ?>" alt="image">
                      <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/noimage.jpg')); ?>" alt="...">
                      <?php endif; ?>
                    </div>
                    <br><br>

                    <input type="hidden" id="fileInput1" name="testimonial_section_image">
                    <button
                      id="chooseImage1"
                      class="choose-image btn btn-primary"
                      type="button"
                      data-multiple="false"
                      data-toggle="modal"
                      data-target="#lfmModal1"
                    ><?php echo e(__('Choose Image')); ?></button>
                    <?php if($errors->has('testimonial_section_image')): ?>
                      <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('testimonial_section_image')); ?></p>
                    <?php endif; ?>

                    
                    <div
                      class="modal fade lfm-modal"
                      id="lfmModal1"
                      tabindex="-1"
                      role="dialog"
                      aria-labelledby="lfmModalTitle"
                      aria-hidden="true"
                    >
                      <i class="fas fa-times-circle"></i>

                      <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-body p-0">
                            <iframe
                              src="<?php echo e(url('laravel-filemanager')); ?>?serial=1"
                              style="width: 100%; height: 500px; overflow: hidden; border: none;"
                            ></iframe>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>

                <div class="form-group">
                  <label for=""><?php echo e(__('Testimonial Section Title*')); ?></label>
                  <input type="text" class="form-control" name="testimonial_section_title" value="<?php echo e($data != null ? $data->testimonial_section_title : ''); ?>">
                  <?php if($errors->has('testimonial_section_title')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('testimonial_section_title')); ?></p>
                  <?php endif; ?>
                </div>

                <div class="form-group">
                  <label for=""><?php echo e(__('Testimonial Section Subtitle*')); ?></label>
                  <input type="text" class="form-control" name="testimonial_section_subtitle" value="<?php echo e($data != null ? $data->testimonial_section_subtitle : ''); ?>">
                  <?php if($errors->has('testimonial_section_subtitle')): ?>
                    <p class="mt-2 mb-0 text-danger"><?php echo e($errors->first('testimonial_section_subtitle')); ?></p>
                  <?php endif; ?>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <div class="row">
            <div class="col-12 text-center">
              <button type="submit" form="testimonialSecForm" class="btn btn-success">
                <?php echo e(__('Update')); ?>

              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="card-title d-inline-block"><?php echo e(__('Testimonials')); ?></div>
          <a
            href="<?php echo e(route('admin.home_page.testimonial_section.create_testimonial') . '?language=' . request()->input('language')); ?>"
            class="btn btn-primary btn-sm float-right"
          ><i class="fas fa-plus"></i> <?php echo e(__('Add Testimonial')); ?></a>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <?php if(count($testimonialInfos) == 0): ?>
                <h3 class="text-center"><?php echo e(__('NO TESTIMONIAL FOUND!')); ?></h3>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-striped mt-3">
                    <thead>
                      <tr>
                        <th scope="col"><?php echo e(__('#')); ?></th>
                        <?php if($websiteInfo->theme_version == 'theme_two'): ?>
                          <th scope="col"><?php echo e(__('Image')); ?></th>
                        <?php endif; ?>
                        <th scope="col"><?php echo e(__('Name')); ?></th>
                        <?php if($websiteInfo->theme_version == 'theme_two'): ?>
                          <th scope="col"><?php echo e(__('Designation')); ?></th>
                        <?php endif; ?>
                        <th scope="col"><?php echo e(__('Comment')); ?></th>
                        <th scope="col"><?php echo e(__('Serial Number')); ?></th>
                        <th scope="col"><?php echo e(__('Actions')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $testimonialInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonialInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <?php if($websiteInfo->theme_version == 'theme_two'): ?>
                            <td>
                              <?php if(!is_null($testimonialInfo->client_image)): ?>
                                <img
                                  src="<?php echo e(asset('assets/img/testimonial_section/' . $testimonialInfo->client_image)); ?>"
                                  alt="user"
                                  width="40"
                                >
                              <?php else: ?>
                                -
                              <?php endif; ?>
                            </td>
                          <?php endif; ?>
                          <td>
                            <?php echo e($testimonialInfo->client_name); ?>

                          </td>
                          <?php if($websiteInfo->theme_version == 'theme_two'): ?>
                            <td>
                              <?php echo e(!is_null($testimonialInfo->client_designation) ? $testimonialInfo->client_designation : '-'); ?>

                            </td>
                          <?php endif; ?>
                          <td>
                            <?php if($websiteInfo->theme_version == 'theme_one'): ?>
                              <?php echo e(strlen($testimonialInfo->comment) > 50 ? convertUtf8(substr($testimonialInfo->comment, 0, 50)) . '...' : convertUtf8($testimonialInfo->comment)); ?>

                            <?php else: ?>
                              <?php echo e(strlen($testimonialInfo->comment) > 20 ? convertUtf8(substr($testimonialInfo->comment, 0, 20)) . '...' : convertUtf8($testimonialInfo->comment)); ?>

                            <?php endif; ?>
                          </td>
                          <td><?php echo e($testimonialInfo->serial_number); ?></td>
                          <td>
                            <a
                              class="btn btn-secondary btn-sm mr-1"
                              href="<?php echo e(route('admin.home_page.testimonial_section.edit_testimonial', $testimonialInfo->id) . '?language=' . request()->input('language')); ?>"
                            >
                              <span class="btn-label">
                                <i class="fas fa-edit" style="margin-right: -3px;"></i>
                              </span>
                            </a>

                            <form
                              class="deleteForm d-inline-block"
                              action="<?php echo e(route('admin.home_page.testimonial_section.delete_testimonial')); ?>"
                              method="post"
                            >
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="testimonial_id" value="<?php echo e($testimonialInfo->id); ?>">

                              <button type="submit" class="btn btn-danger btn-sm deleteBtn">
                                <span class="btn-label">
                                  <i class="fas fa-trash" style="margin-right: -3px;"></i>
                                </span>
                              </button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/home_page/testimonial_section/index.blade.php ENDPATH**/ ?>