<!-- Hero Section Start -->
<section class="hero-section">
    <div id="hero-home-5" class="single-hero-slide bg-img-center d-flex align-items-center text-center lazy" data-bg="<?php echo e(asset('assets/img/hero_static/' . $img)); ?>">
        <div id="bgndVideo" data-property="{videoURL:'<?php echo e($websiteInfo->hero_video_link); ?>',containment:'#hero-home-5', quality:'large', autoPlay:true, loop:true, mute:true, opacity:1}"></div>
        <div class="container">
            <div class="slider-text">
                <span class="small-text" data-animation="fadeInDown" data-delay=".3s"><?php echo e(convertUtf8($title)); ?></span>
                <h1 data-animation="fadeInLeft" data-delay=".6s"><?php echo e(convertUtf8($subtitle)); ?></h1>
                <a class="btn filled-btn" href="<?php echo e($btnUrl); ?>" data-animation="fadeInUp" data-delay=".9s">
                <?php echo e(convertUtf8($btnName)); ?> <i class="far fa-long-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->
<?php /**PATH C:\xampp\htdocs\solusiitkreasi\tampagaram\core\resources\views/frontend/partials/hero/theme1/video.blade.php ENDPATH**/ ?>