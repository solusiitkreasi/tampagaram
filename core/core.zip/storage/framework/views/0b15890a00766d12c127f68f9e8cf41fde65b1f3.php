<?php $__env->startSection('content'); ?>
  <div class="page-header">
    <h4 class="page-title"><?php echo e(__('Services Management')); ?></h4>
    <ul class="breadcrumbs">
      <li class="nav-home">
        <a href="<?php echo e(route('admin.dashboard')); ?>">
          <i class="flaticon-home"></i>
        </a>
      </li>
      <li class="separator">
        <i class="flaticon-right-arrow"></i>
      </li>
      <li class="nav-item">
        <a href="#"><?php echo e(__('Services Management')); ?></a>
      </li>
    </ul>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <div class="row">
            <div class="col-lg-4">
              <div class="card-title d-inline-block"><?php echo e(__('Services')); ?></div>
            </div>

            <div class="col-lg-4 offset-lg-4 mt-2 mt-lg-0">
              <a
                href="<?php echo e(route('admin.services_management.create_service')); ?>"
                class="btn btn-primary btn-sm float-right"
              ><i class="fas fa-plus"></i> <?php echo e(__('Add Service')); ?></a>

              <button
                class="btn btn-danger float-right btn-sm mr-2 d-none bulk-delete"
                data-href="<?php echo e(route('admin.services_management.bulk_delete_service')); ?>"
              ><i class="flaticon-interface-5"></i> <?php echo e(__('Delete')); ?></button>
            </div>
          </div>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <?php if(count($serviceContents) == 0): ?>
                <h3 class="text-center"><?php echo e(__('NO SERVICE FOUND!')); ?></h3>
              <?php else: ?>
                <div class="table-responsive">
                  <table class="table table-striped mt-3" id="basic-datatables">
                    <thead>
                      <tr>
                        <th scope="col">
                          <input type="checkbox" class="bulk-check" data-val="all">
                        </th>
                        <th scope="col"><?php echo e(__('Icon')); ?></th>
                        <th scope="col"><?php echo e(__('Title')); ?></th>
                        <th scope="col"><?php echo e(__('Featured')); ?></th>
                        <th scope="col"><?php echo e(__('Serial Number')); ?></th>
                        <th scope="col"><?php echo e(__('Actions')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $serviceContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <input
                              type="checkbox"
                              class="bulk-check"
                              data-val="<?php echo e($serviceContent->service_id); ?>"
                            >
                          </td>
                          <td><i class="<?php echo e($serviceContent->service->service_icon); ?>"></i></td>
                          <td>
                            <?php echo e(strlen($serviceContent->title) > 30 ? convertUtf8(substr($serviceContent->title, 0, 30)) . '...' : convertUtf8($serviceContent->title)); ?>

                          </td>
                          <td>
                            <form
                              id="featureForm<?php echo e($serviceContent->service_id); ?>"
                              class="d-inline-block"
                              action="<?php echo e(route('admin.services_management.update_featured_service')); ?>"
                              method="post"
                            >
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="serviceId" value="<?php echo e($serviceContent->service_id); ?>">

                              <select
                                class="form-control <?php echo e($serviceContent->service->is_featured == 1 ? 'bg-success' : 'bg-danger'); ?>"
                                name="is_featured"
                                onchange="document.getElementById('featureForm<?php echo e($serviceContent->service_id); ?>').submit();"
                              >
                                <option value="1" <?php echo e($serviceContent->service->is_featured == 1 ? 'selected' : ''); ?>>
                                  <?php echo e(__('Yes')); ?>

                                </option>
                                <option value="0" <?php echo e($serviceContent->service->is_featured == 0 ? 'selected' : ''); ?>>
                                  <?php echo e(__('No')); ?>

                                </option>
                              </select>
                            </form>
                          </td>
                          <td><?php echo e($serviceContent->service->serial_number); ?></td>
                          <td>
                            <a
                              class="btn btn-secondary btn-sm mr-1"
                              href="<?php echo e(route('admin.services_management.edit_service', $serviceContent->service_id)); ?>"
                            >
                              <span class="btn-label">
                                <i class="fas fa-edit"></i>
                              </span>
                              <?php echo e(__('Edit')); ?>

                            </a>

                            <form
                              class="deleteForm d-inline-block"
                              action="<?php echo e(route('admin.services_management.delete_service')); ?>"
                              method="post"
                            >
                              <?php echo csrf_field(); ?>
                              <input
                                type="hidden"
                                name="service_id"
                                value="<?php echo e($serviceContent->service_id); ?>"
                              >
                              <button type="submit" class="btn btn-danger btn-sm deleteBtn">
                                <span class="btn-label">
                                  <i class="fas fa-trash"></i>
                                </span>
                                <?php echo e(__('Delete')); ?>

                              </button>
                            </form>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/backend/services/index.blade.php ENDPATH**/ ?>