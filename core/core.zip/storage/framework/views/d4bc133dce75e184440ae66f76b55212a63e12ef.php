
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.min.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/default.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">


<link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">


<?php if($currentLanguageInfo->direction == 1): ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/rtl.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/rtl-responsive.css')); ?>">
<?php endif; ?>


<link
  rel="stylesheet"
  href="<?php echo e(asset('assets/css/base-color.php?color1=' . $websiteInfo->primary_color . '&color2=' . $websiteInfo->secondary_color)); ?>"
>

<style>
    .breadcrumb-area::after {
        background-color: #<?php echo e($websiteInfo->breadcrumb_overlay_color); ?>;
        opacity: <?php echo e($websiteInfo->breadcrumb_overlay_opacity); ?>;
    }
</style>
<?php /**PATH C:\xampp\htdocs\solusiitkreasi\tampagaram\core\resources\views/frontend/partials/styles.blade.php ENDPATH**/ ?>