<?php $__env->startSection('pageHeading'); ?>
  <?php if(!is_null($pageHeading)): ?>
    <?php echo e($pageHeading->packages_title); ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php
  $metaKeys = !empty($seo->meta_keyword_packages) ? $seo->meta_keyword_packages : '';
  $metaDesc = !empty($seo->meta_description_packages) ? $seo->meta_description_packages : '';
?>

<?php $__env->startSection('meta-keywords', "$metaKeys"); ?>
<?php $__env->startSection('meta-description', "$metaDesc"); ?>

<?php $__env->startSection('content'); ?>
  <main>
    <!-- Breadcrumb Section Start -->
    <section class="breadcrumb-area d-flex align-items-center position-relative bg-img-center lazy" data-bg="<?php echo e(asset('assets/img/' . $breadcrumbInfo->breadcrumb)); ?>" >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <?php if(!is_null($pageHeading)): ?>
            <h1><?php echo e(convertUtf8($pageHeading->packages_title)); ?></h1>
          <?php endif; ?>

          <ul class="list-inline">
            <li><a href="<?php echo e(route('index')); ?>"><?php echo e(__('Home')); ?></a></li>
            <li><i class="far fa-angle-double-right"></i></li>

            <?php if(!is_null($pageHeading)): ?>
              <li><?php echo e(convertUtf8($pageHeading->packages_title)); ?></li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </section>
    <!-- Breadcrumb Section End -->

    <section class="packages-area-v1">
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <div class="packages-sidebar">
                <?php if($websiteInfo->package_category_status == 1): ?>
                    <div class="widget search-widget">
                        <h4 class="widget-title"><?php echo e(__('Categories')); ?></h4>
                        <div class="form_group">
                            <ul class="categories">
                                <li class="<?php if(empty(request()->input('category'))): ?> active <?php endif; ?>"><a href="#" data-category_id=""><?php echo e(__('All')); ?></a></li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php if(request()->input('category') == $category->id): ?> active <?php endif; ?>"><a href="#" data-category_id="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
              <div class="widget search-widget">
                <h4 class="widget-title"><?php echo e(__('Search Here')); ?></h4>
                <div class="form_group">
                  <input
                    type="text"
                    id="searchInput"
                    placeholder="<?php echo e(__('Search By Package Name')); ?>"
                    value="<?php echo e(!empty(request()->input('packageName')) ? request()->input('packageName') : ''); ?>"
                  >
                </div>
              </div>

              <div class="widget location-widget">
                <h4 class="widget-title"><?php echo e(__('Location Search')); ?></h4>
                <div class="form_group">
                  <input
                    type="text"
                    id="locationSearchInput"
                    placeholder="<?php echo e(__('Search By Location')); ?>"
                    value="<?php echo e(!empty(request()->input('locationName')) ? request()->input('locationName') : ''); ?>"
                  >
                </div>
              </div>

              <div class="widget sortby-widget">
                <h4 class="widget-title"><?php echo e(__('Days')); ?></h4>
                <div class="form_group">
                  <select id="days" class="nice-select">
                    <option selected value=""><?php echo e(__('All')); ?></option>
                    <?php for($i=0; $i < $maxDays; $i++): ?>
                        <option value="<?php echo e($i + 1); ?>" <?php echo e(request()->input('daysValue') == $i + 1 ? 'selected' : ''); ?>><?php echo e(__('Up to')); ?> <?php echo e($i + 1); ?> <?php echo e($i + 1 == 1 ? __('Day') : __('Days')); ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
              </div>

              <div class="widget sortby-widget">
                <h4 class="widget-title"><?php echo e(__('Persons')); ?></h4>
                <div class="form_group">
                  <select id="persons" class="nice-select">
                    <option selected value=""><?php echo e(__('All')); ?></option>
                    <?php for($i=0; $i < $maxPersons; $i++): ?>
                        <option value="<?php echo e($i + 1); ?>" <?php echo e(request()->input('personsValue') == $i + 1 ? 'selected' : ''); ?>><?php echo e($i + 1); ?> <?php echo e($i + 1 == 1 ? __('Person & More') : __('Persons & More')); ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
              </div>

              <div class="widget sortby-widget">
                <h4 class="widget-title"><?php echo e(__('Sort By')); ?></h4>
                <div class="form_group">
                  <select id="sortType" class="nice-select">
                    <option
                      value="new-packages"
                      <?php echo e(request()->input('sortValue') == 'new-packages' ? 'selected' : ''); ?>

                    ><?php echo e(__('New Packages')); ?></option>
                    <option
                      value="old-packages"
                      <?php echo e(request()->input('sortValue') == 'old-packages' ? 'selected' : ''); ?>

                    ><?php echo e(__('Old Packages')); ?></option>
                    <option
                      value="price-asc"
                      <?php echo e(request()->input('sortValue') == 'price-asc' ? 'selected' : ''); ?>

                    ><?php echo e(__('Price: Ascending')); ?></option>
                    <option
                      value="price-desc"
                      <?php echo e(request()->input('sortValue') == 'price-desc' ? 'selected' : ''); ?>

                    ><?php echo e(__('Price: Descending')); ?></option>
                    <option
                      value="max-persons-asc"
                      <?php echo e(request()->input('sortValue') == 'max-persons-asc' ? 'selected' : ''); ?>

                    ><?php echo e(__('Maximum Persons: Ascending')); ?></option>
                    <option
                      value="max-persons-desc"
                      <?php echo e(request()->input('sortValue') == 'max-persons-desc' ? 'selected' : ''); ?>

                    ><?php echo e(__('Maximum Persons: Descending')); ?></option>
                    <option
                      value="days-asc"
                      <?php echo e(request()->input('sortValue') == 'days-asc' ? 'selected' : ''); ?>

                    ><?php echo e(__('Number of Days: Ascending')); ?></option>
                    <option
                      value="days-desc"
                      <?php echo e(request()->input('sortValue') == 'days-desc' ? 'selected' : ''); ?>

                    ><?php echo e(__('Number of Days: Descending')); ?></option>
                  </select>
                </div>
              </div>

              <div class="widget price_ranger_widget">
                <h4 class="widget-title"><?php echo e(__('Filter By Price')); ?></h4>
                <div id="slider-range"></div>
                <label for="amount"><?php echo e(__('Price') . ' :'); ?></label>
                <input type="text" id="amount" readonly>
              </div>
            </div>
          </div>

          <div class="col-lg-9">
            <?php if(count($packageInfos) == 0): ?>
              <div class="row text-center">
                <div class="col py-5 bg-light">
                  <h3><?php echo e(__('No Package Found!')); ?></h3>
                </div>
              </div>
            <?php else: ?>
              <div class="packages-wrapper">
                <?php $__currentLoopData = $packageInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $packageInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="packages-post-item">
                    <a class="post-thumbnail d-block" href="<?php echo e(route('package_details', [$packageInfo->package_id, $packageInfo->slug])); ?>">
                      <img class="lazy" data-src="<?php echo e(asset('assets/img/packages/' . $packageInfo->featured_img)); ?>" alt="img">
                    </a>

                    <div class="entry-content">
                      <h3 class="title">
                        <a href="<?php echo e(route('package_details', ['id' => $packageInfo->package_id, 'slug' => $packageInfo->slug])); ?>"><?php echo e(strlen($packageInfo->title) > 70 ? mb_substr($packageInfo->title,0,70,'utf-8') . '...' : $packageInfo->title); ?></a>
                      </h3>
                      <div class="post-meta">
                        <ul>

                          <?php if($packageInfo->pricing_type != 'negotiable'): ?>
                            <li><span><i class="fas fa-comment-dollar"></i><strong><?php echo e(__('Package Price')); ?>:</strong> <?php echo e($currencyInfo->base_currency_symbol_position == 'left' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e($packageInfo->package_price); ?> <?php echo e($currencyInfo->base_currency_symbol_position == 'right' ? $currencyInfo->base_currency_symbol : ''); ?> <?php echo e('(' . __(strtoupper("$packageInfo->pricing_type")) . ')'); ?></span></li>
                          <?php else: ?>
                            <li><span><i class="fas fa-comment-dollar"></i><strong><?php echo e(__('Package Price')); ?>:</strong> <?php echo e(__('NEGOTIABLE')); ?></span></li>
                          <?php endif; ?>

                          <li><span><i class="fas fa-calendar-alt"></i><strong><?php echo e(__('Number of Days')); ?>:</strong> <?php echo e($packageInfo->number_of_days); ?></span></li>

                          <li><span><i class="fas fa-users"></i><strong><?php echo e(__('Maximum Persons')); ?>:</strong> <?php echo e($packageInfo->max_persons != null ? $packageInfo->max_persons : '-'); ?></span></li>
                        </ul>
                      </div>
                    </div>

                    <?php if($packageRating->package_rating_status == 1): ?>
                        <?php
                            $avgRating = \App\Models\PackageManagement\PackageReview::where('package_id', $packageInfo->package_id)->avg('rating');
                        ?>
                        <div class="rate">
                            <div class="rating" style="width:<?php echo e($avgRating * 20); ?>%"></div>
                        </div>
                    <?php endif; ?>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <div class="row">
                <div class="col-12">
                  <?php echo e($packageInfos->appends(['packageName' => request()->input('packageName'),'daysValue' => request()->input('daysValue'),'personsValue' => request()->input('personsValue'),'sortValue' => request()->input('sortValue'),'locationName' => request()->input('locationName'),'minPrice' => request()->input('minPrice'),'maxPrice' => request()->input('maxPrice')])->links()); ?>

                </div>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>

    
    <form class="d-none" action="<?php echo e(route('packages')); ?>" method="GET">
        <?php if($websiteInfo->package_category_status == 1): ?>
        <input type="hidden" id="categoryKey" name="category" value="<?php echo e(request()->input('category')); ?>">
        <?php endif; ?>

      <input type="hidden" id="searchKey" name="packageName" value="<?php echo e(request()->input('packageName')); ?>">

      <input type="hidden" id="daysKey" name="daysValue" value="<?php echo e(request()->input('daysValue')); ?>">

      <input type="hidden" id="personsKey" name="personsValue" value="<?php echo e(request()->input('personsValue')); ?>">

      <input type="hidden" id="sortKey" name="sortValue" value="<?php echo e(request()->input('sortValue')); ?>">

      <input type="hidden" id="locationKey" name="locationName" value="<?php echo e(request()->input('locationName')); ?>">

      <input type="hidden" id="minPriceKey" name="minPrice" value="<?php echo e(request()->input('minPrice')); ?>">

      <input type="hidden" id="maxPriceKey" name="maxPrice" value="<?php echo e(request()->input('maxPrice')); ?>">

      <button type="submit" id="submitBtn"></button>
    </form>
    
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <script>
      "use strict";
      // get the currency symbol position and currency symbol
      var currency_info = <?php echo json_encode($currencyInfo); ?>;
      var minprice = <?php echo htmlspecialchars($minPrice); ?>;
      var maxprice = <?php echo htmlspecialchars($maxPrice); ?>;
      var priceValues = [<?php echo e(!empty(request()->input('minPrice')) ? request()->input('minPrice') : $minPrice); ?>, <?php echo e(!empty(request()->input('maxPrice')) ? request()->input('maxPrice') : $maxPrice); ?>];
  </script>
  <script src="<?php echo e(asset('assets/js/packages.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1579603/public_html/tampagaram/core/resources/views/frontend/packages/packages.blade.php ENDPATH**/ ?>